package MatMathParallel;



public class MainClass {
	public static void main(String args){
		   
			int[ ][ ] A,B,C,D,r,s,t;
			MatMathImpl u = new MatMathImpl();
		   
		   // code to initialize A,B,C,D
		   u.add(A,B,r);
		   u.multiply(r,C,s);
		   u.multiply(s,D,t);

		 }

}
